package me.chanjar.weixin.open.api.impl;

/**
 * @author <a href="https://github.com/007gzs">007</a>
 */
public class WxOpenServiceImpl extends WxOpenServiceApacheHttpClientImpl {

}
