//index.js
//获取应用实例
const app = getApp()
const userData = require('../user')

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    description: '测试一下',
    buttonDes: '测试一下',
    response: '',
    user: {}
  },
  // 检测是否为零
  check0: function () {
    wx.showModal({
      title: "请先登录",
      showCancel: "ture",
      confirmText: "确认",
      confirmcolor: "#ccc",
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },

  getUserInfo: function (e) {    
    app.globalData.userInfo = e.detail.userInfo

    for (var index in userData.data){
      if (userData.data[index].name == e.detail.userInfo.nickName){
        this.setData({
          userInfo: e.detail.userInfo,
          hasUserInfo: true,
          user: userData.data[index]
        })
        return;
      }
      console.log(this.data.user)
    }
  },

  bindButtonTap: function () {
    var that = this;

    if (!this.data.hasUserInfo){
      this.check0();
      return;
    }

    wx.request({
      url: `https://tm.tita.com/api/v1/106454/${this.data.user.id}/Signin/AddV4`,      
      method: 'POST',
      data: { 
        "gcj_coordate": "", 
        "wifi_macaddress": "94:f6:65:17:44:cc",
        "wgs_coordate": "",
        "device_code": this.data.user.device
        },  
      header: {
        'content-type': 'application/x-www-form-urlencoded', 
        'Authorization': this.data.user.token,
        'Accept': '*.*'
      },
      success: function (res) {
        console.log(res.data)
        if (res.statusCode == 200){
          that.setData({
            response: "SUCCESS：" + res.data.Data.signInfo.site_desc
          })
        } else {
          that.setData({
            response: res.statusCode
          })
        }
       
      },
      fail: function(err){
        console.log(this.url)
        console.log("err: " + err)
        that.setData({
          response: JSON.stringify(err)
        }) 
      }
    })

  },
  onLoad: function () {
  }
})
