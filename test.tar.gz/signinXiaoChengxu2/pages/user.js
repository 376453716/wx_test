let data = 
[
   {
    "name": "浩",
    "id": "117665216",
    "token": "nigSGCCaojwU6ecJ19Xvv44i95gag81yBV2_dOvhVKfdRbSyv6np9A",
    "device": "867601036334594"
  },
  {
    "name": "Nio",
    "id": "117250674",
    "token": "eLgsoifh54jgOibCKMTQVmZrLHW3dvwD3rHTYZwVeLxOJThVzObr7w",
    "device": "861337038456913"
  },
  {
    "name": "哄哄",
    "id": "117250674",
    "token": "eLgsoifh54jgOibCKMTQVmZrLHW3dvwD3rHTYZwVeLxOJThVzObr7w",
    "device": "861337038456913"
  }
]

module.exports = {
  data
}  