let data = 
[
  {
    "name":"大大灰灰狼",
    "id" : "118055070",
    "token":"OE7atwtcxo5m5RRqQH9XYgJysAYgZMdMLuS3LqK6YokvjnH-wzM29A",
    "device":"FA653761-BA7E-4E37-A7A3-5F0D07AF455D"
  },
  {
    "name": "珮",
    "id": "114765214",
    "token": "uQ8bUX-s4X-ugp1spZfjrdrC1xnb49jljijp7HKTo2fjes08lMsE6A",
    "device": "567CD29A-DA38-4006-BF0F-AE7995D17609"
  },
  {
    "name": "浩",
    "id": "117665216",
    "token": "z6sWToeoBbeUB3kQCxikkcqxG02iCWRgEh9KY3Hs5HujV4-QdcRt0w",
    "device": "311E0CF0-684A-464C-AEE7-AFB1A9E0BAAB"
  }
]

module.exports = {
  data
}  